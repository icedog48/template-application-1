using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Models
{
    public abstract class _Entity
    {
        public int Id { get; set; }
    }
}
